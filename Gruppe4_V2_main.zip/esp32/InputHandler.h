#ifndef INPUT_HANDLER_H
#define INPUT_HANDLER_H

void inputSetup();
bool button1Pressed();

extern const int potPin;
extern int modeSelect;

#endif