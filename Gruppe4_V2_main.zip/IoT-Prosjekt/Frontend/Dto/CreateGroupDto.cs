﻿namespace Frontend.Dto
{
    public class CreateGroupDto
    {
        public int Id { get; set; }
        public string GroupName { get; set; }
    }
}
