﻿namespace Backend.Dto
{
    public class ChangeDeviceDto
    {
        public bool State { get; set; }
        public string Type { get; set; }
    }
}
