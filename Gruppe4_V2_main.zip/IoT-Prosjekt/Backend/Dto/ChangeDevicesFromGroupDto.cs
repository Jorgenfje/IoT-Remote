﻿namespace Backend.Dto
{
    public class ChangeDevicesFromGroupDto
    {
        public int Id { get; set; }
        public bool State { get; set; }
    }
}
