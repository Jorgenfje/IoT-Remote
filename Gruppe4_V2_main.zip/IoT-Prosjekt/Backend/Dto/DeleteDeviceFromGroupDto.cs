namespace Backend.Dto;

public class DeleteDeviceFromGroupDto
{
    public int GroupId { get; set; }
    public int DeviceId { get; set; }
}