﻿namespace Backend.Domain
{
    public class ApiKey
    {
        public string Key { get; set; }
        public string RemoteId { get; set; }
    }
}
